﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using com.paypal.sdk.util;
using PaypalDemo.Models;
using System.Configuration;
namespace PaypalDemo.Controllers
{
    public class PayController : Controller
    {
        //
        // GET: /Pay/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SetExpressCheckout() {
            string currency = Request.Form["currencyCodeType"];
            string name = Request.Form["NAME"];
            string SHIPTOSTREET = Request.Form["SHIPTOSTREET"];
            string SHIPTOCITY = Request.Form["SHIPTOCITY"];
            string SHIPTOSTATE = Request.Form["SHIPTOSTATE"];
            string SHIPTOCOUNTRYCODE = Request.Form["SHIPTOCOUNTRYCODE"];
            string SHIPTOZIP = Request.Form["SHIPTOZIP"];
            string L_NAME1 = Request.Form["L_NAME1"];
            string L_AMT1 = Request.Form["L_AMT1"];
            string L_QTY1 = Request.Form["L_QTY1"];
            string L_NAME0 = Request.Form["L_NAME0"];
            string L_AMT0 = Request.Form["L_AMT0"];
            string L_QTY0 = Request.Form["L_QTY0"];

            string hots = Request.Url.Scheme + "://" + Request.Url.Host + ":" + Request.Url.Port + "/";

            NVPCodec encoder = new NVPCodec();
            encoder.Add("PAYMENTACTION", "Sale");

            //不允许客户改地址
            encoder.Add("ADDROVERRIDE", "1");
            encoder.Add("CANCELURL", hots + "/Pay/Index");
            encoder.Add("CURRENCYCODE", currency);
            encoder.Add("SHIPTONAME", name);
            encoder.Add("SHIPTOSTREET", SHIPTOSTREET);
            encoder.Add("SHIPTOCITY", SHIPTOCITY);
            encoder.Add("SHIPTOSTATE", SHIPTOSTATE);
            encoder.Add("SHIPTOCOUNTRYCODE", SHIPTOCOUNTRYCODE);
            encoder.Add("SHIPTOZIP", SHIPTOZIP);
            encoder.Add("L_NAME0", L_NAME0);
            encoder.Add("L_NUMBER0", "1000");
            encoder.Add("L_DESC0", "Size: 8.8-oz");
            encoder.Add("L_AMT0", L_AMT0);
            encoder.Add("L_QTY0", L_QTY0);
            encoder.Add("L_NAME1", L_NAME1);
            encoder.Add("L_NUMBER1", "10001");
            encoder.Add("L_DESC1", "Size: Two 24-piece boxes");
            encoder.Add("L_AMT1", L_AMT1);
            encoder.Add("L_QTY1", L_QTY1);
            encoder.Add("L_ITEMWEIGHTVALUE1", "0.5");
            encoder.Add("L_ITEMWEIGHTUNIT1", "lbs");

            double ft = double.Parse(L_QTY0) * double.Parse(L_AMT0) + double.Parse(L_QTY1) * double.Parse(L_AMT1);
            encoder.Add("ITEMAMT", ft.ToString());
            encoder.Add("TAXAMT", "2.00");

            double amt = System.Math.Round(ft + 5.00f + 2.00f + 1.00f, 2);
            double maxamt = System.Math.Round(amt + 25.00f, 2);

            encoder.Add("SHIPDISCAMT","-3.00");
            encoder.Add("AMT",amt.ToString());

             string returnURL = hots + "/Pay/GetExpressCheckoutDetails?amount="+amt.ToString();

            encoder.Add("RETURNURL",returnURL);
            encoder.Add("SHIPPINGAMT", "8.00");
            encoder.Add("MAXAMT", maxamt.ToString());

            encoder.Add("INSURANCEOPTIONOFFERED", "true");
            encoder.Add("INSURANCEAMT", "1.00");

            encoder.Add("LOCALECODE", "US");

            encoder.Add("NOSHIPPING", "1");

            encoder.Add("L_SHIPPINGOPTIONISDEFAULT0", "false");
            encoder.Add("L_SHIPPINGOPTIONNAME0", "Ground");
            encoder.Add("L_SHIPPINGOPTIONLABEL0", "UPS Ground 7 Days");
            encoder.Add("L_SHIPPINGOPTIONAMOUNT0", "3.00");
            encoder.Add("L_SHIPPINGOPTIONISDEFAULT1", "true");
            encoder.Add("L_SHIPPINGOPTIONNAME1", "UPS Air");
            encoder.Add("L_SHIPPINGOPTIONlABEL1", "UPS Next Day Air");
            encoder.Add("L_SHIPPINGOPTIONAMOUNT1", "8.00");

            encoder.Add("CALLBACKTIMEOUT", "4");

            NVPCodec decoder = PaypalProvider.SetExpressCheckout(encoder);

            string ack = decoder["ACK"];
            string L_ERRORCODE0 = decoder["L_ERRORCODE0"];
            string L_SHORTMESSAGE0 = decoder["L_SHORTMESSAGE0"];
            string L_LONGMESSAGE0 = decoder["L_LONGMESSAGE0"];
            string L_SEVERITYCODE0 = decoder["L_SEVERITYCODE0"];
           
            if (!string.IsNullOrEmpty(ack) &&
                (ack.Equals("Success", System.StringComparison.OrdinalIgnoreCase) || ack.Equals("SuccessWithWarning", System.StringComparison.OrdinalIgnoreCase))
                )
            {
                // 发送电子邮件
                //new MailManager(email, "订单", "订单信息").Send();
                Session["TOKEN"] = decoder["token"];
                return Redirect(ConfigurationManager.AppSettings["RedirectURL"] + decoder["token"]);

            }
            else
            {
                return Redirect("/Pay/Index");
            }
        }

        //得到通过支付方得到的信息
        public ActionResult GetExpressCheckoutDetails(string amount)
        {

            //得到支付详细信息
            string token = Session["TOKEN"].ToString();
            NVPCodec nvp = new NVPCodec();
            nvp.Add("TOKEN", token);
            nvp.Add("CURRENCYCODE", "USD");


            NVPCodec responsenvp = PaypalProvider.GetExpressCheckoutDetails(nvp);
            string ack = responsenvp["ACK"];

            if (string.IsNullOrEmpty(ack) ||
                (
                    !ack.Equals("Success", System.StringComparison.OrdinalIgnoreCase) &&
                    !ack.Equals("SuccessWithWarning", System.StringComparison.OrdinalIgnoreCase))
                )
            {
              
                return Redirect("/Pay/Index");
            }
            string payerstatus = responsenvp["PAYERSTATUS"];
            string email = responsenvp["EMAIL"];
            string payerid = responsenvp["PAYERID"];
            string firstname = responsenvp["FIRSTNAME"];
            string lastname = responsenvp["LASTNAME"];

            //开始支付

            NVPCodec donvp = new NVPCodec();
            donvp.Add("TOKEN", token);
            donvp.Add("AMT", amount);
            donvp.Add("PAYERID", payerid);
            donvp.Add("PAYMENTACTION", "Sale");
            donvp.Add("CURRENCYCODE", "USD");

            NVPCodec response_do = PaypalProvider.DoExpressCheckoutPayment(donvp);
            string do_ack = response_do["ACK"];

            string L_ERRORCODE0 = response_do["L_ERRORCODE0"];
            string L_SHORTMESSAGE0 = response_do["L_SHORTMESSAGE0"];
            string L_LONGMESSAGE0 = response_do["L_LONGMESSAGE0"];
            string L_SEVERITYCODE0 = response_do["L_SEVERITYCODE0"];
            if (string.IsNullOrEmpty(do_ack) ||
                (
                    !do_ack.Equals("Success", System.StringComparison.OrdinalIgnoreCase) &&
                    !do_ack.Equals("SuccessWithWarning", System.StringComparison.OrdinalIgnoreCase))
                )
            {
                return Redirect("/Pay/Index");
            }
            else {

                string paymenttype = response_do["PAYMENTTYPE"];
                string transactionID = response_do["TRANSACTIONID"];
                string note = response_do["NOTE"];
                string ordertime = response_do["ORDERTIME"];
                string paymentstatus = response_do["PAYMENTSTATUS"];
                string reason=response_do["PENDINGREASON"];
                double feeamt = double.Parse(response_do["FEEAMT"]);
                return Content("恭喜您支付成功！");
            }

        }

    }
}
