﻿using System.Web.Mvc;
using System;

namespace PaypalDemo.Models
{

    public class RequestControllerBase : Controller
    {
        protected OnlineUserStruct _onlineuser;
        public RequestControllerBase()
        {

            string custom_clientcode = SFCookie.GetCookie(CookieInfo.CLIENTCODE);
            string custom_autocode = SFCookie.GetCookie(CookieInfo.AUTOCODE);
            string custom_ip = SFRequest.GetIP();



            bool clear_autocode = false;
            _onlineuser = OnlineState.GuestLogin(custom_clientcode, custom_autocode, custom_ip, ref clear_autocode);
            if (_onlineuser != null)
            {
                System.Web.HttpContext.Current.Items.Add("request_user", _onlineuser);
                if (_onlineuser.ClientCode != custom_clientcode)
                {
                    SFCookie.WriteCookie(CookieInfo.CLIENTCODE, _onlineuser.ClientCode, 30 * 365 * 24 * 60, Config.SiteConfigs.GetConfig().CookieDomain);
                }
                if (clear_autocode)
                {
                    SFCookie.WriteCookie(CookieInfo.AUTOCODE, -1, Config.SiteConfigs.GetConfig().CookieDomain);
                }
            }
            else
            {
                Logger.Error(new System.Diagnostics.StackFrame(true), "无法让用户登陆");
                System.Web.HttpContext.Current.Response.Write("<center>站点正在维护中。。。</center>");
                System.Web.HttpContext.Current.Response.End();
            }



            ViewData[CookieInfo.AUTOCODE] = AutoCode;
            ViewData[CookieInfo.SESSIONCODE] = SessionCode;
            ViewData[CookieInfo.SERVERPATH] = ServerPath;
            ViewData[CookieInfo.CLIENTCODE] = ClientCode;
            ViewData[CookieInfo.USERNAME] = UserName;
            ViewData[CookieInfo.ISLOGIN] = IsLogin;
            ViewData[CookieInfo.VIPSTATUS] = VIPStatus;
            ViewData[CookieInfo.USERID] = UserID;
        }

        #region Fileds

        protected OnlineUserStruct OnlineUser
        {
            get
            {
                if (_onlineuser == null)
                {
                    _onlineuser = Request.User();
                }
                return _onlineuser;
            }
        }
        /// <summary>
        /// 自动登陆代码
        /// </summary>
        protected string AutoCode
        {
            get
            {
                return SFCookie.GetCookie(CookieInfo.AUTOCODE);
            }
        }

        /// <summary>
        /// 会话令牌
        /// </summary>
        protected string SessionCode
        {
            get
            {
                return OnlineUser.SessionCode;
            }
        }

        /// <summary>
        /// HTTP服务器地址
        /// </summary>
        protected string ServerPath
        {
            get
            {
                return OnlineUser.Url;
            }
        }

        /// <summary>
        /// 客户端标识码
        /// </summary>
        protected string ClientCode
        {
            get
            {
                return SFCookie.GetCookie(CookieInfo.CLIENTCODE);
            }
        }

        /// <summary>
        /// 得到登陆用户的用户名
        /// </summary>
        protected string UserName
        {
            get
            {
                return OnlineUser.UserName;
            }
        }

        /// <summary>
        /// 判断是否已经登陆
        /// </summary>
        protected bool IsLogin
        {
            get
            {
                if (OnlineUser.UserID > 0)
                {
                    return true;
                }
                return false;
            }
        }

        /// <summary>
        /// 用户身份状态
        /// </summary>
        protected int VIPStatus
        {
            get
            {
                if (OnlineUser.UserID <= 0)
                {
                    return 0;
                }

                if (UserServicesBLL.HasAis(OnlineUser.IASStartDate, OnlineUser.IASEndDate))
                {
                    return OnlineUser.VipStatus;
                }
                return 1;
            }
        }

        /// <summary>
        /// 用户编号,0为Guest
        /// </summary>
        protected long UserID
        {
            get
            {
                return OnlineUser.UserID;
            }
        }

        /// <summary>
        /// Action传递给Controller的信息
        /// </summary>
        protected string Msg
        {
            get;
            set;
        }

        public int Status
        {
            get;
            set;
        }


        #endregion


    }
}
