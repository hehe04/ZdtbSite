﻿using System.Web.Mvc;

namespace PaypalDemo.Models
{
    public class WebControllerBase : RequestControllerBase
    {

        public WebControllerBase()
        {
            ViewData["ShowEnglishLink"] = true;
            ViewData["ShowChineseLink"] = true;
        }


    }
}
